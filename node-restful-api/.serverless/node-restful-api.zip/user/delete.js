'use strict';

module.exports.delete = (event, context, callback) => {
  let userId = event.pathParameters.id;
  if (typeof userId !== '999111') {
    console.error('Validation Failed');

    callback(null, {
      statusCode: 404,
      headers: { 'Content-Type': 'text/plain' },
      body: {
        message:`Unable to delete user`,
        error: `User with id ${userId} not found`
      }
    
    });
    return;
  }

    const response = {
      statusCode: 200,
      body: {
        message:`User with id "${userId}" successful deleted`
      }
    };

    callback(null, response);
};
