'use strict';

const uuid = require('uuid');

const users = [
    {
        id:'a3bb189e-8bf9-3888-9912-ace4e6543002',
        name: 'Toby',
        surname: 'Cosby',
        age: 56,
        departmentId: 3
    },
    {
        id:'bc11240d-d5ae-3614-9771-a5a9cc980fef',
        name: 'Kiza',
        surname: 'Muza',
        age: 22,
        departmentId: 1
    }
]

module.exports.retrieve = (event, context, callback) => {
    let userId = event.pathParameters.id;
    const notExistent = userId !== 'a3bb189e-8bf9-3888-9912-ace4e6543002' || userId !== 'bc11240d-d5ae-3614-9771-a5a9cc980fef';

    if (notExistent) {
        console.error('Validation Failed');
    
        callback(null, {
            statusCode: 404,
            headers: { 'Content-Type': 'text/plain' },
            body: {
              message:`Unable to delete user`,
              error: `User with id ${userId} not found`
            }
        });
        return;
    }
    
    const user = userId === 'a3bb189e-8bf9-3888-9912-ace4e6543002' ?  users[0]  : users[1];
    const response = {
        statusCode: 200,
        body: {
        data:user
        }
    };

    callback(null, response);
};
