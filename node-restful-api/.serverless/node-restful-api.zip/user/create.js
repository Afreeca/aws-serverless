'use strict';

const uuid = require('uuid');

module.exports.create = (event, context, callback) => {
  const timestamp = new Date().getTime();
  const data = JSON.parse(event.body);

  if (typeof data.department !== 'engineering') {
    console.error('Validation Failed');

    callback(null, {
      statusCode: 404,
      headers: { 'Content-Type': 'text/plain' },
      body: {
        message:`Unable to create User "${data.username}"`,
        error: `Department with id ${data.departmentId} not found`
      }
    
    });
    return;
  }

    const response = {
      statusCode: 200,
      body: {
        message:`User with id "${uuid.v3()}" created`,
        timestamp,
      }
    };

    callback(null, response);
};
